package com.ltw.domain.validator.phone;

public @interface PhoneNumber {
}
