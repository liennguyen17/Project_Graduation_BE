package com.ltw.exception;

public class BaseValidateException extends RuntimeException{
    public BaseValidateException(String message){
        super(message);
    }
}
