package com.ltw.service.mapper;

public interface TopicUpdateMapper {
}
