package com.ltw.dto.request.topic;

import lombok.Data;

@Data
public class StudentCreateTopicRequest {
    private Integer teacher;
    private String nameTopic;
    private String status;
}
