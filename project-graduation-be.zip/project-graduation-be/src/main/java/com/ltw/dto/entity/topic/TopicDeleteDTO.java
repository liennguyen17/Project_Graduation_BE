package com.ltw.dto.entity.topic;

import lombok.Data;

@Data
public class TopicDeleteDTO {
    private Integer id;
}
