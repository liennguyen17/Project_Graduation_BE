package com.ltw.dto.entity.users;

import lombok.Data;

@Data
public class UserDeleteDTO {
    private Integer id;
}
