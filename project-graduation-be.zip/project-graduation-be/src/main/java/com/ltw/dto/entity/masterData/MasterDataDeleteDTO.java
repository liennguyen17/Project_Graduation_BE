package com.ltw.dto.entity.masterData;

import lombok.Data;

@Data
public class MasterDataDeleteDTO {
    private Integer id;
}
