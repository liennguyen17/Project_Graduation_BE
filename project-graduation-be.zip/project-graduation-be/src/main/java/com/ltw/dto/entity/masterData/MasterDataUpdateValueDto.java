package com.ltw.dto.entity.masterData;

import lombok.Data;

@Data
public class MasterDataUpdateValueDto {
    private Integer id;
    private String type;
    private String code;
    private String name;
}
