package com.ltw.dto.entity.role;

import lombok.Data;

@Data
public class RoleDTO {
    private Integer id;
    private String name;
    private String description;
}
