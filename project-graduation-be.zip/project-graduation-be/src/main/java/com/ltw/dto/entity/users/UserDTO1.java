package com.ltw.dto.entity.users;

import lombok.Data;

@Data
public class UserDTO1 {
    private Integer id;
    private String name;
    private String subject;
    private String role;
}
