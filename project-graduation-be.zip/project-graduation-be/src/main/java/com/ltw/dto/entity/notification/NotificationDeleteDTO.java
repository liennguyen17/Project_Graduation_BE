package com.ltw.dto.entity.notification;

import lombok.Data;

@Data
public class NotificationDeleteDTO {
    private Integer id;
}
