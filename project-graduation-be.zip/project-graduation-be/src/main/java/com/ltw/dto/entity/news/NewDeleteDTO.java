package com.ltw.dto.entity.news;

import lombok.Data;

@Data
public class NewDeleteDTO {
    private Integer id;
}
