package com.ltw.dto.entity.topic;

import com.ltw.dto.entity.users.UserDTO1;
import lombok.Data;

@Data
public class TopicDTO1 {
    private Integer id;
    private UserDTO1 student;
    private UserDTO1 teacher;
    private String nameTopic;
}
