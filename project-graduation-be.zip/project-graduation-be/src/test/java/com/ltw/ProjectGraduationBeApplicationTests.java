package com.ltw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectGraduationBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
